package Videojuego;

public class Main {
public static void main(String[] args) {
		
	Gestor gestor = new Gestor();
	gestor.menu();
}
}